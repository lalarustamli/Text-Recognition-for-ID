<!DOCTYPE html>
<head>
    <style>
        table, td, tr, th{
            border-collapse: collapse;
            border:1px solid black
        }
    </style>
</head>
<body>       
    <?php
        $conn_link=@mysqli_connect ("localhost", "root", "12345", "hack") or die("It cannot connect to database!");
        $query_select="select * from id_info";
        $result=mysqli_query($conn_link, $query_select) or die (mysqli_error($conn_link));
        echo "<table>";
        echo "<tr><th>Ad</th>
                  <th>Soyad</th>
                  <th>Ata adi</th>
                  <th>Dogum tarixi</th>
                  <th>Qeydiyyat unvani</th>
                  <th>Verilme tarixi</th>
                  <th>Etibarliliq muddeti</th>
                  <th>Company</th>
                  <th>Department</th>
                  <th>Fin kod</th>
                  <th>Redakte</th>
                  <th>Sil</th>
                  </tr>";
        while($myarray=mysqli_fetch_assoc($result)){
            echo '<tr>';
            echo '<td>'.$myarray['first_name'].'</td>';
            echo '<td>'.$myarray['last_name'].'</td>';
            echo '<td>'.$myarray['father_name'].'</td>';
            echo '<td>'.$myarray['birth_date'].'</td>';
            echo '<td>'.$myarray['register_local'].'</td>';
            echo '<td>'.$myarray['given_date'].'</td>';
            echo '<td>'.$myarray['valid_date'].'</td>';
            echo '<td>'.$myarray['company'].'</td>';
            echo '<td>'.$myarray['dapartment'].'</td>';
            echo '<td>'.$myarray['fin_code'].'</td>';
            echo "<td><a href='update_data.php?user_id=".$myarray['id']."'><button type='button'>Redakte et</button></a></td>";
            echo "<td><a href='delete_data.php?user_id=".$myarray['id']."'><button type='button'>Sil</button></a></td>";
            echo '<tr>';

        }
    ?>

</table>
</body>
</html>

